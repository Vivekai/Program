

class AppData:
    def __init__(self):
        self.items = [('Rusty Bucket', '40L bucket - quite rusty', 0.0),
                      ('Golf Cart', 'Tesla powered 250 turbo', 195.0),
                      ('Thermomix', 'TM-31', 25.5),
                      ('Aeropress','Great coffee maker',5),
                      ('Guitar','JTV-59',12.95),
                      ('Guitar', 'Vintage wood', 5.9),
                      ('Guitar', 'Vintage wood', 6.9),
                      ('Guitar', 'Vintage wood', 7.9),
                      ('Guitar', 'Vintage wood', 8.9),]

    def getItems(self):
       return self.items