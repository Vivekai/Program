input_file = open("items.csv",'r')        #imporing .csv file get file and reading csv file
for line in input_file:                                  # Reading each line from .csv file
 print(line,end=' ')                                     #Display each line



FILENAME = "items.csv"
DISPLAY_OPTION = {'all':0 , 'in':1 , 'out':2, 'zero':0}


print("Items for hire - by VIVEK SRIRAM 5 items loaded from items.csv")




#display MENU list

def displaymenu(): #define function
  menutext = """Menu:
(L)ist all items
(H)ire an item
(R)eturn an item
(A)dd new item to stock1
(Q)uit"""



 # ask user to input an option and convert it to capital letter
  try:
      user_input = (input(menutext)).upper()

      while user_input not in ('L','H','R','A','Q'):
        user_input = input(menutext)
        user_input = user_input.upper()
  except:
      print('Invalid input,enter valid input')
  finally:
      return user_input




def readitems(filename):
    Item_list = []
    try:
        with open(filename,'r') as file:
         for line in file:
            if len(line) == 0:
              continue
            else:
              fields = line.rstrip("\n").split(',')                 #display file
            Item_list.append([fields[0],fields[1],fields[2],fields[3]])
    except:
         print("Missing .csv file")
         print ("Error occured while processing file")
    finally:
        return Item_list

def saveitemstofile(filename, itemlist):
    try:
        with open(filename, 'w') as f:
            for i in range(len(itemlist)):
                line = '{},{},{},{}\n'.format(itemlist[i][0], itemlist[i][1], itemlist[i][2], itemlist[i][3])
                f.write(line)
    except:
        print('Error occured while saving items back to {} file.\n'.format(filename))
    finally:
        return


def list_items(Item_list,option):
    SPACE = 50
    if option ==  DISPLAY_OPTION ['all']:
        print("All items on file(* indicates currently out)")
        for i in range(len(Item_list)):
            if 'out' in Item_list[i][3] :
              status = '*'
            else:
              status = ' '
            line = '{} - {} ({})'.format(i,Item_list[i][0],Item_list[i][1])
            line =  line.ljust(SPACE)
            line +=' = ${:>6.2f} {}'.format(float(Item_list[i][2]),status)
            print(line)

    elif option == DISPLAY_OPTION ['in']:
        for i in range(len(Item_list)):
            if 'in' in Item_list[i][3]:
              line = '{} - {} ({})'.format(i,Item_list[i][0],Item_list[i][1])
              line = line.ljust(SPACE)
              line += ' = ${:>6.2f}'.format(float(Item_list[i][2]))
              print(line)

    elif option == DISPLAY_OPTION['out']:
        # display items can be returned
        for i in range(len(Item_list)):
            if 'out' in Item_list[i][3]:
                line = '{} - {} ({})'.format(i, Item_list[i][0], Item_list[i][1])
                line = line.ljust(SPACE)
                line += ' = ${:>6.2f}'.format(float(Item_list[i][2]))
                print(line)

def hired(Item_list):
   availableitems = []
   for i in range(len(Item_list)):
        if Item_list[i][3] == 'in':
            availableitems.append(i)

   item_index = -1
   user_input = input('Enter the number of items to hire:')

   if not user_input.isdecimal() or int(user_input) not in availableitems:
       print('That item is not available for hire')
   else:
       item_index = int(user_input)
       Item_list[item_index][3] = 'out'

   return item_index

def displayitemhired(Item_list,item_index):

   print("Rusty bucket hired")

def returnitem(Item_list):
    returningItems = []
    for i in range(len(Item_list)):
      if Item_list[i][3] == 'out':
        returningItems.append(i)

    Item_index = 1
    user_input = input("Enter the number of items to return:")


    if not user_input.isdecimal() or int(user_input) not in returningItems:
        print("No items are currently on hire")
    else:
        Itemindex = int(user_input)
        Item_list[Item_index][3] = 'in'
    return Item_index

def displayitem(Item_list,Item_index):
      print("Thermomix Returned")


def returnitem(Item_list):
    returnItems = []
    for i in range(len(Item_list)):
      if Item_list[i][3] == 'out':
            returnItems.append(i)


    Item_index = 0
    user_input = input("Enter the number of items to return")



    if not user_input.isdecimal() or int(user_input) not in returnItems:
        print("No items are currently on hire")
    else:
        Item_index = int(user_input)
        Item_list[Item_index][3] = 'in'


    return Item_index

def displayreturnitem(Item_list,Item_index):
     print("Rusty bucket returned")


def Add_item():
    name_list = []

    counter = 4                                    #Initiate counter
    counter < 3

    list_1 = input("Item name : ")               #obtain user input
    try:                                                                     #Handling with Exception
        if list_1 != '':
            list_1 = input(" ")
        list_1 = input("Item name : ")
    except ValueError:
        print("Input cannot be blank")
    list_2 = input("Description:")
    list_3 = input("Price per day: $")
    try:                                                                      #Handling with Exception
        if list_3 != "-12":
         list_3 = input("Price per day: $")
    except ValueError:
        print("Invalid input; enter a valid number")
    try:
        if list_3 != "cheap":
          print("Price must be >= $0")
        list_3 = input("Price per day: $")
    except ValueError:
        print("Invalid input; enter a valid number")

    list_4 = input("Guitar (JTV-59)  ,$12.95 now available for hire")
    name_list.append(list_1)
    name_list.append(list_2)
    name_list.append(list_3)
    name_list.append(list_4)
    counter += 1

    output_file = open("items.csv", "w")                # add the data to the list
    print(name_list,file=output_file)
    output_file.close()

if __name__ == '__main__':
  _DEBUG_ = True

  Item_list = readitems(FILENAME)

  if len(Item_list) == 0:
      running = False
  else:
      running = True
 #Initiating menu
  while (running):

    menu = displaymenu()

    if menu == 'L' :
        list_items(Item_list,DISPLAY_OPTION['all'])

    elif menu == 'H' :                                       #selecting h from menu
      list_items(Item_list,DISPLAY_OPTION['in'])
      item_index = hired(Item_list)
      if item_index > -1:
          displayitemhired(Item_list,item_index)

    elif menu == 'R':
      list_items(Item_list,DISPLAY_OPTION['out'])
      Item_index = returnitem(Item_list)
      #Item_index = ReturnItem(Item_list)
      if Item_index < 1:
        displayreturnitem(Item_list,Item_index)
      else:
        displayitem(Item_list,Item_index)

    elif menu == 'A':
        Add_new_item()

    elif menu == 'Q':
        print('Have a nice day')
        running = False






