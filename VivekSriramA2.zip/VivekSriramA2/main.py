""" @NAME VIVEK SRIRAM
    Date is 31/5/2016
    Program details includes three python file (Item.py,main.py,VivekSriramA1.py) ,kivy file "main.kv" and a csv file
    Github link:  https://github.com/Vivekai/Program.git

"""

from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import random

import data
import math


# for add new item
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput


class MainApp(App):                                                              #Invoking MainApp class and object App
    input_value = StringProperty()

    def build(self):
        self.title = 'Equipment hire'                           # Title window
        self.root = Builder.load_file('VivekSriramA2.kv')       #Load kivy file

        self.items = self.listitems()                           #listitems

        return self.root


    def listitems(self):                                                                    #Function for listing items
        # set button color
        btn_colors = [[1, 0.5, 0, 1], [0, 1, 1, 1], [0.5, 0, 1, 1]]  # red, green, blue
        # set number of buttons per row
        itemsperrow = 3

        items_layout = BoxLayout(padding=0, orientation="vertical")

        myData = data.AppData()                                                            #Data.py object invoke with class Appdata
        myItems = myData.getItems()                                                        #GetItems
        totalItems = len(myItems)
        numofrows = math.ceil(totalItems / itemsperrow)
        if _DEBUG_:
            print('{}, {}'.format(totalItems, numofrows))

        for i in range(numofrows):
            row_layout = BoxLayout(padding=0)
            for j in range(itemsperrow):
                itemno = i * itemsperrow + j
                print('item {}'.format(itemno))                                             # Listing current items
                if itemno < totalItems:
                    item_btn_title = "Item {}: {}".format(itemno, myItems[itemno][0])       #Listing items
                    item_btn = Button(text = item_btn_title,
                                      id = str(itemno),
                                      on_press=self.item_selected,
                                      background_color=random.choice(btn_colors) )          # properties of Button object
                    row_layout.add_widget(item_btn)
            items_layout.add_widget(row_layout)

        self.root.ids.bx_items.add_widget(items_layout)
        return myItems


    def menu_pressed(self, instance):
        if instance == self.root.ids.menu_list:
            if _DEBUG_: print('Menu List Item is selected.')                                       #pressing menu list item button
            self.root.ids.lb_status.text = self.root.ids.menu_list.text
        elif instance == self.root.ids.menu_hire:
            if _DEBUG_: print('Menu Hire Item is selected.')                                       #pressing menu hire item buttton
            self.root.ids.lb_status.text = self.root.ids.menu_hire.text
        elif instance == self.root.ids.menu_return:
            if _DEBUG_: print('Menu Return Item is selected.')                                     #pressing Return item button
            self.root.ids.lb_status.text = self.root.ids.menu_return.text
        elif instance == self.root.ids.menu_add:
            if _DEBUG_: print('Menu Add New Item is selected.')                                    #pressing Add - New-item button
            # for add new item
            self.root.ids.lb_status.text = self.root.ids.menu_add.text                             # showing menu_add in label control
            self.newitembox = self.addnewitembox()
            self.popup = Popup(title='Add New Item', content = self.newitembox,                    # TO-DO Add New Item title window pop-up
                               size_hint=(0.6, 0.8))
            self.popup.open()
        elif instance == self.root.ids.menu_confirm:
            if _DEBUG_: print('Menu Confirm is selected.')                                        # Confirm item in box layout
            App.get_running_app().stop()


    def item_selected(self, instance):
        if _DEBUG_: print('Item {} is selected.'.format(instance.id))

    # for add new item


    def addnewitembox(self):
        box = BoxLayout(orientation='vertical')                                              # Adding BoxLayout
        box.add_widget(TextInput(text='Enter item name', id='name'))                         # Adding text widget for box layout
        box.add_widget(TextInput(text='Enter item description', id='desc', multiline=True))
        box.add_widget(TextInput(text='Enter price',id='price'))
        box.add_widget(Button(text='Add',  on_press=self.save))                           # Adding button control to box layout
        box.add_widget(Button(text='Cancel',on_press=self.closepopup))

        return box





    def handle_newitem(self, instance, value):                                                 # New item
        print(value)

    def closepopup(self, instance):                                                            # Close add new itwm window pop up
        for child in self.newitembox.children:
            if child.id == 'name':
                print('item name is {}'.format(child.text) )                                   #Display item name
            elif child.id == 'desc':
                print('item description is {}'.format(child.text) )                            #Display item description

        # to-do:
        # first add new item to the itemlist,
        # then udpate the items in main window

        # close popup window
        self.popup.dismiss()



if __name__ == '__main__':                                                                          # Main app window GUI opens
    _DEBUG_ = True
    app = MainApp()
    app.run()
    